
document.addEventListener("DOMContentLoaded", function(event) {

var tries = 0;
var num = random(); //number corresponding to a random element in an array

var word = new Array(6);
var text = new Array(6);

word = ["MONKEY", "TIGER", "ELEPHANT", "GORILLA", "SHARK", "TURTLE"];
text = ["_ _ _ _ _ _", "_ _ _ _ _", "_ _ _ _ _ _ _ _", "_ _ _ _ _ _ _", "_ _ _ _ _", "_ _ _ _ _ _"];

var wordLength = word[num].length;

function random() {
  return Math.floor(Math.random()*6);
}
console.log(random());

//document.write(text[num]);
console.log(text[num]);

document.getElementById("screenText").innerHTML = text[num];

//var d2 = document.getElementById("textDiv");
//d2.appendChild(document.write(text[num]));

function myFunction() {
  var d = document.getElementById("buttonDiv");
//this creates 6 buttons, you will need 26
if (tries == 0) {
  tries += 1;
  for(x=1;x<=26;x++){
	  //use the createElement function to create known HTML elements
    var btn = document.createElement("BUTTON");
	  var myP = document.createElement("br");

	  //why start at 64? Because the letter 'A' is code 65
    var letter = String.fromCharCode(x+64);
    var t = document.createTextNode(letter);
	  //add the text stored in 't' to our button variable
    btn.appendChild(t);
	  //give the btn an id to make it easy to access later
    btn.id = letter;
    btn.className = "buttonClass";
	  //this is how to add an event to the button -- name the event and
	  //then include the function you want it to perform
    btn.addEventListener("click", pickLetter);
    btn.addEventListener("click", checkLetter);
    //add the btn to the page
	  d.appendChild(btn);
	  //add a line break 'myP' after 13 buttons
	  if (x%13==0) {
	     d.appendChild(myP);
	    }
    }
  }
}
function checkLetter() {
  //do I need to do this? can I just call letter?
  letter = this.id;
  newText = "";
  //checks if the letter is in the word
  if (word[num].includes(letter)) { //checks if the word has the letter
    for (i=0;i<wordLength;i++) { //finds and replaces the dashes with the letter
      if (word[num].charAt(i)==letter) { //finds what position the first letter is in
        newText = newText + letter + " ";
      } else {
        newText = newText + text[num].charAt(2*i) + " "; //x2 for the spaces between the dashes
      }
    }
    text[num] = newText;
    console.log(text[num]);
    document.getElementById("screenText").innerHTML = text[num];
  } else { //the word doesn't have the letter
    //
  }
}

function pickLetter(){
	//"this" refers to the object that called this function
	document.getElementById("p1").innerHTML += this.id;
	//document.getElementById("picBox").innerHTML = "Change this to a picture of your choice";
}
function changeColor(){
	this.style.backgroundColor="blue";
}

});

function myFunction() {
  var d = document.getElementById("buttonDiv");
//this creates 6 buttons, you will need 26
if (tries == 0) {
  tries += 1;
  for(x=1;x<=26;x++){
	  //use the createElement function to create known HTML elements
    var btn = document.createElement("BUTTON");
	  var myP = document.createElement("br");

	  //why start at 64? Because the letter 'A' is code 65
    var letter = String.fromCharCode(x+64);
    var t = document.createTextNode(letter);
	  //add the text stored in 't' to our button variable
    btn.appendChild(t);
	  //give the btn an id to make it easy to access later
    btn.id = letter;
    btn.className = "buttonClass";
	  //this is how to add an event to the button -- name the event and
	  //then include the function you want it to perform
    btn.addEventListener("click", pickLetter);
    btn.addEventListener("click", checkLetter);
    //add the btn to the page
	  d.appendChild(btn);
	  //add a line break 'myP' after 13 buttons
	  if (x%13==0) {
	     d.appendChild(myP);
	    }
    }
  }
}
